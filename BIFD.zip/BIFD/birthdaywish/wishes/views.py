from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import google.generativeai as genai

# ✅ Configure Gemini API Key (Make sure to hide this key in production!)
genai.configure(api_key="AIzaSyDynuOnYEfZ6s34pfwuseItJ8iAvzHl6a8")

# ✅ Dashboard Page
def dashboard(request):
    return render(request, 'dashboard.html')

# ✅ Gallery Page (videos + images)
def videos(request):
    return render(request, 'video.html')

# ✅ Prayers Page
def prayers(request):
    return render(request, 'prayers.html')

# ✅ Gemini-powered Birthday Wish Generator
@csrf_exempt
def home(request):
    gemini_response = None

    if request.method == 'POST':
        message = request.POST.get('message') or ""

        try:
            # Use Gemini model (latest)
            model = genai.GenerativeModel(model_name="models/gemini-1.5-flash")

            prompt = f"""
            Write a heartfelt, creative birthday message for someone very special.
            Message Input: {message}
            """

            response = model.generate_content(prompt)
            gemini_response = response.text

        except Exception as e:
            gemini_response = "❌ Gemini API Error: " + str(e)

    return render(request, 'home.html', {
        'gemini_response': gemini_response
    })
